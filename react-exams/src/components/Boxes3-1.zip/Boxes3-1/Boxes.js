import React from 'react';
import Box1 from "./Box1";
import "./style.css"

const Boxes= ()=>{
    return (<div><Box1/></div>)
}
export default Boxes