import React from "react";

const Box4 = () => {
    return ( <div className = "box4" > </div>
    );
}
export default Box4;